import tkinter as tk

from gui_dnagenerator import *
from gui_dnamenu import *
from gui_nucleotidecounter import *
from gui_dnapresenter import *

from gui_invcomp import *
from gui_dnapresenter2 import *

from gui_cadrecode import *
from gui_dnapresenter3 import *


if __name__ == '__main__':
    print("in main")
    root=tk.Tk()
    root.title("Transformateur d'ADN")


# Barre des menus
    wmen=WDnaMenu(root)
    wmen.pack()
    

# Fenetre 1
    f1=tk.Frame(bd=2)
    f1.pack(padx=10, pady=10, fill=tk.BOTH, expand=1)

    wgen=WDnaGenerator(f1)
    wcnt=WNucleotideCounter(f1)
    
    wgen.pack(side=tk.LEFT)
    wcnt.pack(side=tk.RIGHT)

    wpres1=WDnaPresenter(root)
    wpres1.pack(fill=tk.BOTH, expand=1)


# Fenetre 2
    f2=tk.Frame(bd=2)
    f2.pack(padx=10, pady=10, fill=tk.BOTH, expand=1)
    
    text2=tk.Label(f2, text="Séquence d'ADN :       ")
    text2.pack(side=tk.LEFT)

    winvcomp=invcomp(f2)
    winvcomp.pack(side=tk.LEFT)

    wpres2=Presenter2(root)
    wpres2.pack(fill=tk.BOTH, expand=1)



# Fenetre 3
    f3=tk.Frame(bd=2)
    f3.pack(padx=10, pady=10, fill=tk.BOTH, expand=1)
    
    wcadrecode=cadrecode(f3)
    wcadrecode.pack(side=tk.LEFT)

    wpres3=Presenter3(root)
    wpres3.pack(fill=tk.BOTH, expand=1)


# Lien ntre les differentes actions
    root.bind_all("<<NewDNA>>", wpres1.onNewDnaSequenceEvent)
    root.bind_all("<<UpdateDNA>>", wcnt.onUpdateDnaSequenceEvent)
    
    root.bind_all("<<NewSEQ>>",winvcomp.onNewSeqEvent)
    root.bind_all("<<UpdateSEQ>>",wpres2.onUpdateSeqEvent)
    
    root.bind_all("<<NewPROT>>",wcadrecode.onNewProtEvent)
    root.bind_all("<<UpdatePROT>>",wpres3.onUpdateProtEvent)
    
    root.bind_all("<<CutDNA>>",wpres1.enleverDNA)
    root.bind_all("<<CopyDNA>>",wpres1.reprendreDNA)
    root.bind_all("<<PasteDNA>>",wpres1.remettreDNA)
    
    
    root.mainloop()
