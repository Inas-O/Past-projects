import tkinter as tk
import cadreConRev as prog



class invcomp(tk.Frame):
    def __init__(self, racine=None):
        tk.Frame.__init__(self, racine)
        self.racine=racine
        self.brin=None
        self.createWidget()
        
    def createWidget(self):
        self.selection = tk.StringVar()
        self.selection.set('0')
        self.inv=tk.Radiobutton(self, text="Inverse", variable=self.selection, value='0', command=self.InvComp)
        self.comp=tk.Radiobutton(self, text="Complémentaire", variable=self.selection, value='1', command=self.InvComp)
        self.inv.pack(side=tk.LEFT)
        self.comp.pack(side=tk.LEFT)
    
    def InvComp(self):
        selection=self.selection.get()
        brin=self.brin
        print("chgmt inv/comp",brin)
        if selection == '0':
            print("inverse")
            self.seq=prog.inverse(brin)
            print(self.seq)
        elif selection == '1':
            print("complémentaire")
            self.seq=prog.complementaire(brin)
            print(self.seq)
        self.event_generate("<<UpdateSEQ>>")
        
    def onNewSeqEvent(self, event):
        brin=event.widget.getDNA()
        self.brin=brin
        selection=self.selection.get()
        print("boncle invcomp",''.join(brin))
        print(selection)
        if selection == '0':
            print("inverse")
            self.seq=prog.inverse(brin)
            print(self.seq)
        elif selection == '1':
            print("complémentaire")
            self.seq=prog.complementaire(brin)
            print(self.seq)
        self.event_generate("<<UpdateSEQ>>")
        
    def getSeq(self):
        return self.seq
    
    def keepDNA(self):
        return self.brin
        
        






		