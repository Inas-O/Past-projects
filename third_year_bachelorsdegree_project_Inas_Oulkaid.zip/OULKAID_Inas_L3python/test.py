from tkinter import *
 
  
 
def ouvrir():
    patryck = PhotoImage(file='tabcodon.png')
    item = can1.create_image(510, 375, image = patryck)
    can1.image = patryck
    can1.pack()
 
fen = Tk()
 
fileMenu = Menubutton(fen, text = 'TEST')
 
fileMenu.pack(side = TOP)
 
me1 = Menu(fileMenu)
 
me1.add_command(label = 'Ouvrir', command = ouvrir)
 
fileMenu.configure(menu = me1)
 
  
 
can1 = Canvas(fen, width = 1015, height = 750, bg = 'white')
 
  
 
fen.mainloop ()