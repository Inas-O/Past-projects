def fastaReader(name):
    with open(name, "r") as f:
        line=f.readline()
        seq=f.readline()[:-1]

        for line in f:
            seq+=line[:-1]

    return seq

if __name__ == '__main__' :
    seq=fastaReader("./test.fasta")
    print(len(seq), " <", seq, ">", sep="")
