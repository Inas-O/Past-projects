import tkinter as tk
import cadreConRev as prog

class cadrecode(tk.Frame):
    def __init__(self, racine=None):
        tk.Frame.__init__(self, racine)
        self.racine=racine
        self.brin=None
        self.createWidget()

    def createWidget(self):
        self.txt1 = tk.Label(self, text='Séquence Protéque :    ')
        self.txt1.pack(side=tk.LEFT)
        
        self.txt2 = tk.Label(self, text='Cadre de lecture:')
        self.txt2.pack(side=tk.LEFT)
        
        self.ca = tk.StringVar()
        self.ca.set('1')
        self.cadre1=tk.Radiobutton(self, text="1", variable=self.ca, value='1', command=self.cadrecode)
        self.cadre2=tk.Radiobutton(self, text="2", variable=self.ca, value='2', command=self.cadrecode)
        self.cadre3=tk.Radiobutton(self, text="3", variable=self.ca, value='3', command=self.cadrecode)
        self.cadre1.pack(side=tk.LEFT)
        self.cadre2.pack(side=tk.LEFT)
        self.cadre3.pack(side=tk.LEFT)
        
        self.txt3 = tk.Label(self, text='    Code à lettre(s) :')
        self.txt3.pack(side=tk.LEFT)
        
        self.co = tk.StringVar()
        self.co.set('1')
        self.co1=tk.Radiobutton(self, text="1", variable=self.co, value='1', command=self.cadrecode)
        self.co3=tk.Radiobutton(self, text="3", variable=self.co, value='3', command=self.cadrecode)
        self.co1.pack(side=tk.LEFT)
        self.co3.pack(side=tk.LEFT)

        
    def cadrecode(self):
        cadre=self.ca.get()
        code=self.co.get()
        brin=self.brin
        if cadre == '1':
            if code == '1': 
                print("chgmt cadre 1 code 1")
                self.prot=prog.cadrecode11(brin)
            elif code == '3':
                 print("chgmt cadre 1 code 3")
                 self.prot=prog.cadrecode13(brin)
        elif cadre == '2':
            if code == '1': 
                print("chgmt cadre 2 code 1")
                self.prot=prog.cadrecode21(brin)
            elif code == '3':
                 print("chgmt cadre 2 code 3")
                 self.prot=prog.cadrecode23(brin)
        elif cadre == '3':
            if code == '1': 
                print("chgmt cadre 3 code 1")
                self.prot=prog.cadrecode31(brin)
            elif code == '3':
                 print("chgmt cadre 3 code 3")
                 self.prot=prog.cadrecode33(brin)
        self.event_generate("<<UpdatePROT>>")
        
    def onNewProtEvent(self, event):
        brin=event.widget.getDNA()
        self.brin=brin
        ca=self.ca.get()
        co=self.co.get()
        if ca == '1':
            if co == '1': 
                print("cadre 1 code 1")
                self.prot=prog.cadrecode11(brin)
            elif co == '3':
                 print("cadre 1 code 3")
                 self.prot=prog.cadrecode13(brin)
        elif ca == '2':
            if co == '1': 
                print("cadre 2 code 1")
                self.prot=prog.cadrecode21(brin)
            elif co == '3':
                 print("cadre 2 code 3")
                 self.prot=prog.cadrecode23(brin)
        elif ca == '3':
            if co == '1': 
                print("cadre 3 code 1")
                self.prot=prog.cadrecode31(brin)
            elif co == '3':
                 print("cadre 3 code 3")
                 self.prot=prog.cadrecode33(brin)
        self.event_generate("<<UpdatePROT>>")
        
    def getProt(self):
        return self.prot
    
    def keepDNA(self):
        return self.brin
        
        
        
        
        
        
        
        
        