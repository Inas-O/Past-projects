import tkinter as tk

class Presenter3(tk.Frame):
    def __init__(self, racine=None):
        "Affiche la séquence d'ADN dasn un widget Text"
        tk.Frame.__init__(self, racine)
        self.racine=racine
        self.createWidget()

    def createWidget(self):
        self.vsb=tk.Scrollbar(self, orient=tk.VERTICAL)
        self.vsb.pack(fill=tk.Y, side=tk.RIGHT)
        
        self.textprot=tk.Text(self, width=60, height=10, bd=5)
        self.textprot['yscrollcommand']=self.vsb.set
        self.textprot.config(state=tk.DISABLED)
        
        self.vsb.config(command=self.textprot.yview)
        
        self.textprot.pack(side=tk.LEFT, padx=10, pady=10, fill=tk.BOTH, expand=1)
        
    def onUpdateProtEvent(self, event):
        print("Update Prot")
        prot=event.widget.getProt()
        brin=event.widget.keepDNA()
        print(brin)
        self.textprot.config(state=tk.NORMAL)
        self.textprot.delete("0.0",tk.END)
        self.textprot.insert(tk.END," ".join(prot))
        self.textprot.config(state=tk.DISABLED)

