import tkinter as tk

class Presenter2(tk.Frame):
    def __init__(self, racine=None):
        "Affiche la séquence d'ADN dasn un widget Text"
        tk.Frame.__init__(self, racine)
        self.racine=racine
        self.createWidget()

    def createWidget(self):
        self.vsb=tk.Scrollbar(self, orient=tk.VERTICAL)
        self.vsb.pack(fill=tk.Y, side=tk.RIGHT)
        
        self.textseq=tk.Text(self, width=60, height=10, bd=5)
        self.textseq['yscrollcommand']=self.vsb.set
        self.textseq.config(state=tk.DISABLED)
        
        self.vsb.config(command=self.textseq.yview)
        
        self.textseq.pack(side=tk.LEFT, padx=10, pady=10, fill=tk.BOTH, expand=1)
        
    def onUpdateSeqEvent(self, event):
        print("Update Sequence")
        seq=event.widget.getSeq()
        self.textseq.config(state=tk.NORMAL)
        self.textseq.delete("0.0",tk.END)
        self.textseq.insert(tk.END,"".join(seq))
        self.textseq.config(state=tk.DISABLED)

