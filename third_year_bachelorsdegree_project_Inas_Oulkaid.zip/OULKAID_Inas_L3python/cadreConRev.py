def complementaire(brin):
    brinstr=''.join(brin)
    brinstr = brinstr.upper()
    comp = []
    for i in range(len(brin)):
        if brin[i] == 'A':
            comp.append('T')
        elif brin[i] == 'T':
            comp.append('A')
        elif brin[i] == 'C':
            comp.append('G')
        elif brin[i] == 'G':
            comp.append('C')
    comp = ''.join(comp)
    return comp

def inverse(brin):
	invbrin = ''.join(reversed(brin))
	return invbrin

def cadrecode13(brin):
    brin = brin.upper()
    listbrin=list(brin)
    prot =[]
    i = 0
    print(listbrin)
    while i <= len(listbrin)-3:
        if listbrin[i] == 'T':
            if listbrin[i+1] == 'T':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C':
                    prot.append('Phe')
                elif listbrin[i+2] == 'A' or listbrin[i+2] == 'G':
                    prot.append('Leu')
            elif listbrin[i+1] == 'C':
                prot.append('Ser')
            elif listbrin[i+1] == 'A':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C':
                    prot.append('Tyr')
                elif listbrin[i+2] == 'A' or listbrin[i+2] == 'G':
                    prot.append('STOP')
                    break
            elif listbrin[i+1] == 'G':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C':
                    prot.append('Cys')
                elif listbrin[i+2] == 'A':
                    prot.append('STOP')
                    break
                elif listbrin[i+2] == 'G':
                    prot.append('Trp')             
        if listbrin[i] == 'C':
            if listbrin[i+1] == 'T':
                prot.append('Leu')
            elif listbrin[i+1] == 'C':
                prot.append('Pro')
            elif listbrin[i+1] == 'A':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C':
                    prot.append('His')
                elif listbrin[i+2] == 'A' or listbrin[i+2] == 'G':
                    prot.append('Gln')
            elif listbrin[i+1] == 'G':
                prot.append('Arg')
        if listbrin[i] == 'A':
            if listbrin[i+1] == 'T':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C' or listbrin[i+2] == 'A':
                    prot.append('Ile')
                elif listbrin[i+2] == 'G':
                    prot.append('Met')
            elif listbrin[i+1] == 'C':
                prot.append('Thr')
            elif listbrin[i+1] == 'A':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C':
                    prot.append('Asn')
                elif listbrin[i+2] == 'A' or listbrin[i+2] == 'G':
                    prot.append('Lys')
            elif listbrin[i+1] == 'G':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C':
                    prot.append('Ser')
                elif listbrin[i+2] == 'A' or listbrin[i+2] == 'G':
                    prot.append('Arg')
        if listbrin[i] == 'G':
            if listbrin[i+1] == 'T':
                prot.append('Val')
            elif listbrin[i+1] == 'C':
                prot.append('Ala')
            elif listbrin[i+1] == 'A':
                if listbrin[i+2] == 'T' or listbrin[i+2]== 'C':
                    prot.append('Asp')
                elif listbrin[i+2] == 'A' or listbrin[i+2] == 'G':
                    prot.append('Glu')
            elif listbrin[i+1] == 'G':
                prot.append('Gly')
        i = i + 3
    print(prot)
    return prot

def cadrecode11(brin):
    brin = brin.upper()
    listbrin=list(brin)
    prot =[]
    i = 0
    print(listbrin)
    while i <= len(listbrin)-3:
        if listbrin[i] == 'T':
            if listbrin[i+1] == 'T':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C':
                    prot.append('F')
                elif listbrin[i+2] == 'A' or listbrin[i+2] == 'G':
                    prot.append('L')
            elif listbrin[i+1] == 'C':
                prot.append('S')
            elif listbrin[i+1] == 'A':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C':
                    prot.append('Y')
                elif listbrin[i+2] == 'A' or listbrin[i+2] == 'G':
                    prot.append('STOP')
                    break
            elif listbrin[i+1] == 'G':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C':
                    prot.append('C')
                elif listbrin[i+2] == 'A':
                    prot.append('STOP')
                    break
                elif listbrin[i+2] == 'G':
                    prot.append('W')             
        if listbrin[i] == 'C':
            if listbrin[i+1] == 'T':
                prot.append('K')
            elif listbrin[i+1] == 'C':
                prot.append('P')
            elif listbrin[i+1] == 'A':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C':
                    prot.append('H')
                elif listbrin[i+2] == 'A' or listbrin[i+2] == 'G':
                    prot.append('Q')
            elif listbrin[i+1] == 'G':
                prot.append('R')
        if listbrin[i] == 'A':
            if listbrin[i+1] == 'T':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C' or listbrin[i+2] == 'A':
                    prot.append('I')
                elif listbrin[i+2] == 'G':
                    prot.append('M')
            elif listbrin[i+1] == 'C':
                prot.append('T')
            elif listbrin[i+1] == 'A':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C':
                    prot.append('N')
                elif listbrin[i+2] == 'A' or listbrin[i+2] == 'G':
                    prot.append('K')
            elif listbrin[i+1] == 'G':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C':
                    prot.append('S')
                elif listbrin[i+2] == 'A' or listbrin[i+2] == 'G':
                    prot.append('R')
        if listbrin[i] == 'G':
            if listbrin[i+1] == 'T':
                prot.append('V')
            elif listbrin[i+1] == 'C':
                prot.append('A')
            elif listbrin[i+1] == 'A':
                if listbrin[i+2] == 'T' or listbrin[i+2]== 'C':
                    prot.append('D')
                elif listbrin[i+2] == 'A' or listbrin[i+2] == 'G':
                    prot.append('E')
            elif listbrin[i+1] == 'G':
                prot.append('G')
        i = i + 3
    print(prot)
    return prot
    
def cadrecode23(brin):
    brin = brin.upper()
    listbrin=list(brin)
    prot =[]
    i = 0
    listbrin.pop(0)
    print(listbrin)
    while i <= len(listbrin)-3:
        if listbrin[i] == 'T':
            if listbrin[i+1] == 'T':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C':
                    prot.append('Phe')
                elif listbrin[i+2] == 'A' or listbrin[i+2] == 'G':
                    prot.append('Leu')
            elif listbrin[i+1] == 'C':
                prot.append('Ser')
            elif listbrin[i+1] == 'A':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C':
                    prot.append('Tyr')
                elif listbrin[i+2] == 'A' or listbrin[i+2] == 'G':
                    prot.append('STOP')
                    break
            elif listbrin[i+1] == 'G':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C':
                    prot.append('Cys')
                elif listbrin[i+2] == 'A':
                    prot.append('STOP')
                    break
                elif listbrin[i+2] == 'G':
                    prot.append('Trp')             
        if listbrin[i] == 'C':
            if listbrin[i+1] == 'T':
                prot.append('Leu')
            elif listbrin[i+1] == 'C':
                prot.append('Pro')
            elif listbrin[i+1] == 'A':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C':
                    prot.append('His')
                elif listbrin[i+2] == 'A' or listbrin[i+2] == 'G':
                    prot.append('Gln')
            elif listbrin[i+1] == 'G':
                prot.append('Arg')
        if listbrin[i] == 'A':
            if listbrin[i+1] == 'T':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C' or listbrin[i+2] == 'A':
                    prot.append('Ile')
                elif listbrin[i+2] == 'G':
                    prot.append('Met')
            elif listbrin[i+1] == 'C':
                prot.append('Thr')
            elif listbrin[i+1] == 'A':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C':
                    prot.append('Asn')
                elif listbrin[i+2] == 'A' or listbrin[i+2] == 'G':
                    prot.append('Lys')
            elif listbrin[i+1] == 'G':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C':
                    prot.append('Ser')
                elif listbrin[i+2] == 'A' or listbrin[i+2] == 'G':
                    prot.append('Arg')
        if listbrin[i] == 'G':
            if listbrin[i+1] == 'T':
                prot.append('Val')
            elif listbrin[i+1] == 'C':
                prot.append('Ala')
            elif listbrin[i+1] == 'A':
                if listbrin[i+2] == 'T' or listbrin[i+2]== 'C':
                    prot.append('Asp')
                elif listbrin[i+2] == 'A' or listbrin[i+2] == 'G':
                    prot.append('Glu')
            elif listbrin[i+1] == 'G':
                prot.append('Gly')
        i = i + 3
    print(prot)
    return prot
    
def cadrecode21(brin):
    brin = brin.upper()
    listbrin=list(brin)
    prot =[]
    i = 0
    listbrin.pop(0)
    print(listbrin)
    while i <= len(listbrin)-3:
        if listbrin[i] == 'T':
            if listbrin[i+1] == 'T':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C':
                    prot.append('F')
                elif listbrin[i+2] == 'A' or listbrin[i+2] == 'G':
                    prot.append('L')
            elif listbrin[i+1] == 'C':
                prot.append('S')
            elif listbrin[i+1] == 'A':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C':
                    prot.append('Y')
                elif listbrin[i+2] == 'A' or listbrin[i+2] == 'G':
                    prot.append('STOP')
                    break
            elif listbrin[i+1] == 'G':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C':
                    prot.append('C')
                elif listbrin[i+2] == 'A':
                    prot.append('STOP')
                    break
                elif listbrin[i+2] == 'G':
                    prot.append('W')             
        if listbrin[i] == 'C':
            if listbrin[i+1] == 'T':
                prot.append('K')
            elif listbrin[i+1] == 'C':
                prot.append('P')
            elif listbrin[i+1] == 'A':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C':
                    prot.append('H')
                elif listbrin[i+2] == 'A' or listbrin[i+2] == 'G':
                    prot.append('Q')
            elif listbrin[i+1] == 'G':
                prot.append('R')
        if listbrin[i] == 'A':
            if listbrin[i+1] == 'T':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C' or listbrin[i+2] == 'A':
                    prot.append('I')
                elif listbrin[i+2] == 'G':
                    prot.append('M')
            elif listbrin[i+1] == 'C':
                prot.append('T')
            elif listbrin[i+1] == 'A':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C':
                    prot.append('N')
                elif listbrin[i+2] == 'A' or listbrin[i+2] == 'G':
                    prot.append('K')
            elif listbrin[i+1] == 'G':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C':
                    prot.append('S')
                elif listbrin[i+2] == 'A' or listbrin[i+2] == 'G':
                    prot.append('R')
        if listbrin[i] == 'G':
            if listbrin[i+1] == 'T':
                prot.append('V')
            elif listbrin[i+1] == 'C':
                prot.append('A')
            elif listbrin[i+1] == 'A':
                if listbrin[i+2] == 'T' or listbrin[i+2]== 'C':
                    prot.append('D')
                elif listbrin[i+2] == 'A' or listbrin[i+2] == 'G':
                    prot.append('E')
            elif listbrin[i+1] == 'G':
                prot.append('G')
        i = i + 3
    print(prot)
    return prot
    
def cadrecode33(brin):
    brin = brin.upper()
    listbrin=list(brin)
    prot =[]
    i = 0
    listbrin.pop(0)
    listbrin.pop(0)
    print(listbrin)
    while i <= len(listbrin)-3:
        if listbrin[i] == 'T':
            if listbrin[i+1] == 'T':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C':
                    prot.append('Phe')
                elif listbrin[i+2] == 'A' or listbrin[i+2] == 'G':
                    prot.append('Leu')
            elif listbrin[i+1] == 'C':
                prot.append('Ser')
            elif listbrin[i+1] == 'A':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C':
                    prot.append('Tyr')
                elif listbrin[i+2] == 'A' or listbrin[i+2] == 'G':
                    prot.append('STOP')
                    break
            elif listbrin[i+1] == 'G':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C':
                    prot.append('Cys')
                elif listbrin[i+2] == 'A':
                    prot.append('STOP')
                    break
                elif listbrin[i+2] == 'G':
                    prot.append('Trp')             
        if listbrin[i] == 'C':
            if listbrin[i+1] == 'T':
                prot.append('Leu')
            elif listbrin[i+1] == 'C':
                prot.append('Pro')
            elif listbrin[i+1] == 'A':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C':
                    prot.append('His')
                elif listbrin[i+2] == 'A' or listbrin[i+2] == 'G':
                    prot.append('Gln')
            elif listbrin[i+1] == 'G':
                prot.append('Arg')
        if listbrin[i] == 'A':
            if listbrin[i+1] == 'T':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C' or listbrin[i+2] == 'A':
                    prot.append('Ile')
                elif listbrin[i+2] == 'G':
                    prot.append('Met')
            elif listbrin[i+1] == 'C':
                prot.append('Thr')
            elif listbrin[i+1] == 'A':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C':
                    prot.append('Asn')
                elif listbrin[i+2] == 'A' or listbrin[i+2] == 'G':
                    prot.append('Lys')
            elif listbrin[i+1] == 'G':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C':
                    prot.append('Ser')
                elif listbrin[i+2] == 'A' or listbrin[i+2] == 'G':
                    prot.append('Arg')
        if listbrin[i] == 'G':
            if listbrin[i+1] == 'T':
                prot.append('Val')
            elif listbrin[i+1] == 'C':
                prot.append('Ala')
            elif listbrin[i+1] == 'A':
                if listbrin[i+2] == 'T' or listbrin[i+2]== 'C':
                    prot.append('Asp')
                elif listbrin[i+2] == 'A' or listbrin[i+2] == 'G':
                    prot.append('Glu')
            elif listbrin[i+1] == 'G':
                prot.append('Gly')
        i = i + 3
    print(prot)
    return prot
    
def cadrecode31(brin):
    brin = brin.upper()
    listbrin=list(brin)
    prot =[]
    i = 0
    listbrin.pop(0)
    listbrin.pop(0)
    print(listbrin)
    while i <= len(listbrin)-3:
        if listbrin[i] == 'T':
            if listbrin[i+1] == 'T':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C':
                    prot.append('F')
                elif listbrin[i+2] == 'A' or listbrin[i+2] == 'G':
                    prot.append('L')
            elif listbrin[i+1] == 'C':
                prot.append('S')
            elif listbrin[i+1] == 'A':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C':
                    prot.append('Y')
                elif listbrin[i+2] == 'A' or listbrin[i+2] == 'G':
                    prot.append('STOP')
                    break
            elif listbrin[i+1] == 'G':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C':
                    prot.append('C')
                elif listbrin[i+2] == 'A':
                    prot.append('STOP')
                    break
                elif listbrin[i+2] == 'G':
                    prot.append('W')             
        if listbrin[i] == 'C':
            if listbrin[i+1] == 'T':
                prot.append('K')
            elif listbrin[i+1] == 'C':
                prot.append('P')
            elif listbrin[i+1] == 'A':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C':
                    prot.append('H')
                elif listbrin[i+2] == 'A' or listbrin[i+2] == 'G':
                    prot.append('Q')
            elif listbrin[i+1] == 'G':
                prot.append('R')
        if listbrin[i] == 'A':
            if listbrin[i+1] == 'T':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C' or listbrin[i+2] == 'A':
                    prot.append('I')
                elif listbrin[i+2] == 'G':
                    prot.append('M')
            elif listbrin[i+1] == 'C':
                prot.append('T')
            elif listbrin[i+1] == 'A':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C':
                    prot.append('N')
                elif listbrin[i+2] == 'A' or listbrin[i+2] == 'G':
                    prot.append('K')
            elif listbrin[i+1] == 'G':
                if listbrin[i+2] == 'T' or listbrin[i+2] == 'C':
                    prot.append('S')
                elif listbrin[i+2] == 'A' or listbrin[i+2] == 'G':
                    prot.append('R')
        if listbrin[i] == 'G':
            if listbrin[i+1] == 'T':
                prot.append('V')
            elif listbrin[i+1] == 'C':
                prot.append('A')
            elif listbrin[i+1] == 'A':
                if listbrin[i+2] == 'T' or listbrin[i+2]== 'C':
                    prot.append('D')
                elif listbrin[i+2] == 'A' or listbrin[i+2] == 'G':
                    prot.append('E')
            elif listbrin[i+1] == 'G':
                prot.append('G')
        i = i + 3
    print(prot)
    return prot
    
