import tkinter as tk

class WDnaPresenter(tk.Frame):
    def __init__(self, racine=None):
        "Affiche la séquence d'ADN dasn un widget Text"
        tk.Frame.__init__(self, racine)
        self.racine=racine
        self.createWidget()

    def createWidget(self):
        self.vsb=tk.Scrollbar(self, orient=tk.VERTICAL)
        self.vsb.pack(fill=tk.Y, side=tk.RIGHT)
        
        self.textDna=tk.Text(self, width=60, height=10, bd=5)
        self.textDna['yscrollcommand']=self.vsb.set
        self.textDna.config(state=tk.DISABLED)
        
        self.vsb.config(command=self.textDna.yview)
        
        self.textDna.pack(side=tk.LEFT, padx=10, pady=10, fill=tk.BOTH, expand=1)

    def onNewDnaSequenceEvent(self, event):
        print("Remplacement vieu par nouveau")
        brin=event.widget.getDNA()
        self.textDna.config(state=tk.NORMAL)
        self.textDna.delete("0.0",tk.END)
        self.textDna.insert(tk.END,"".join(brin))
        self.textDna.config(state=tk.DISABLED)
        self.event_generate("<<UpdateDNA>>")
        self.event_generate("<<NewSEQ>>")
        self.event_generate("<<NewPROT>>")

    def getDNA(self):
        brin= self.textDna.get(1.0, tk.END)
        brin=brin.strip(" \n")
        return brin
    
    def enleverDNA(self, event):
        self.clipboard_clear()
        self.clipboard_append(self.textDna.get(1.0, tk.END))
        self.textDna.config(state=tk.NORMAL)
        self.textDna.delete("0.0",tk.END)
        self.textDna.insert(tk.END,"")
        self.textDna.config(state=tk.DISABLED)
        self.event_generate("<<UpdateDNA>>")
        self.event_generate("<<NewSEQ>>")
        self.event_generate("<<NewPROT>>")
        
    
    def reprendreDNA(self, event):
        self.clipboard_clear()
        self.clipboard_append(self.textDna.get(1.0, tk.END))
        
    def remettreDNA(self, event):
        self.textDna.config(state=tk.NORMAL)
        self.textDna.delete("0.0",tk.END)
        self.textDna.insert(tk.END,self.clipboard_get())
        self.textDna.config(state=tk.DISABLED)
        self.event_generate("<<UpdateDNA>>")
        self.event_generate("<<NewSEQ>>")
        self.event_generate("<<NewPROT>>")
        

if __name__ == '__main__':
    import dnagen as dna
    class Appli(tk.Tk):
        def __init__(self):
            tk.Tk.__init__(self)

        def getDNA(self):
            brin=dna.genereDNA(50)
            print("brin de root:<","".join(brin),">",sep="")
            return brin

    def sendNewDnaEvent():
        print("new DNA event")
        root.event_generate("<<NewDNA>>")
        root.after(2000, sendNewDnaEvent )

    def onUpdateDnaSequenceEvent(event):
        brin=event.widget.getDNA()
        print("Update:<",brin,">", sep="")
        

    print("in main")
    root=Appli()
    wpres=WDnaPresenter(root)
    wpres.pack()
    wpres.bind_all("<<NewDNA>>", wpres.onNewDnaSequenceEvent)
    root.bind_all("<<UpdateDNA>>", onUpdateDnaSequenceEvent)
    print("In loop")
    root.after(2000, sendNewDnaEvent )
    
    root.mainloop()
