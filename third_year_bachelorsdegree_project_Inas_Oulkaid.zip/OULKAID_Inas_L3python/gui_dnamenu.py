import tkinter as tk
import tkinter.filedialog as tkf
import fastareader as fasta


class WDnaMenu(tk.Frame):
    def __init__(self, racine=None):
        "Le constructeur de la menubar"
        tk.Frame.__init__(self, racine)
        self.racine=racine
        self.menu=tk.Menu(racine)
        self.createMenu()
        racine.config(menu=self.menu)
        

    def createMenu(self):
        w=self.menu
        w.add_cascade(label="Fichier", menu=self.createFileMenu())
        w.add_cascade(label="Edition", menu=self.createEditMenu())
        w.add_cascade(label="Outils", menu=self.createToolMenu())
   
    def createFileMenu(self):
        m=tk.Menu(self, tearoff=0)
        m.add_command(label="Ouvrir Fasta", command=self.cmdOpenFasta)
        #m.add_command(label="Enregistrer", command=lambda : self.cmdSaveFasta("File.Save"))
        m.add_separator()
        m.add_command(label="Quitter", command=self.racine.destroy)
        return m

    def createEditMenu(self):
        m = tk.Menu(self, tearoff=0)
        m.add_command(label="Couper", command=lambda : self.cutCmd("Edit.Cut"))
        m.add_command(label="Copier", command=lambda : self.copyCmd("Edit.Copy"))
        m.add_command(label="Coller", command=lambda : self.pasteCmd("Edit.Paste"))
        return m

    def createToolMenu(self):
        m = tk.Menu(self, tearoff=0)
        m.add_command(label="Tableau des codons", command=lambda : self.tool1Cmd("Tableau des codons"))
        return m

    def tool1Cmd(self, menu):
        self.top = tk.Toplevel(width = 1015, height = 750, bg = 'white')
        self.top.title("Tableau des codons")
        self.tabcodon = tk.PhotoImage(file='tabcodon.PNG')
        self.can1 = tk.Canvas(self.top, width = 1015, height = 750, bg = 'white')
        self.item = self.can1.create_image(510, 375, image = self.tabcodon)
        self.can1.image = self.tabcodon
        self.can1.pack()
        
    def cutCmd(self, menu):
        print('Couper')
        self.event_generate("<<CutDNA>>")
           
    def copyCmd(self, menu):
        print('Copier')
        self.event_generate("<<CopyDNA>>")
        
    def pasteCmd(self, menu):
        print('Coller')
        self.event_generate("<<PasteDNA>>")

    #def cmdSaveFasta(self):
        

    def cmdOpenFasta(self):
        opts = {    'filetypes': (('fasta', '.fasta'),
                              ('fsta', '.fsta'),
                              ('Text files', '.txt'),
                              ('All files', '.*'),)}
        opts['title'] = 'Select a file to open...'
        fn = tkf.askopenfilename(**opts)
        if len(fn) > 0 :
            self.seq=fasta.fastaReader(fn)
            print("in cmdOpenFasta", self.bindtags())
            print("length:", len(self.seq))
            self.event_generate("<<NewDNA>>")
            

    def getDNA(self):
        return self.seq
    

        
if __name__ == '__main__':
    
    def affiche(event):
        print("in affiche")
        print(event.widget.getDNA())
        
    print("in main")
    root=tk.Tk()
    fm=WDnaMenu(root)
    fm.pack()
    
    root.bind_all("<<NewDNA>>", affiche)
    
    root.mainloop()
