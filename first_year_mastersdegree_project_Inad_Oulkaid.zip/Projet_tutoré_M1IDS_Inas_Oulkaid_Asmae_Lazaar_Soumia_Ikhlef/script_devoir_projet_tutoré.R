########Devoir projet tutoré, J.Godet
#PRENOMS: Inas Oulkaid, Asmae Lazaar, Soumia Ikhlef
################################################################


#Librairies à apeller, si la librairies est non installé: install.packages("librayname")
library("tidyverse")
library("ggmap")
library("countrycode")
library("janitor")
library("ggplot2")
library("viridis")
require("lubridate")
require("ggmap")



#######################################CARTE DU MONDE########################################################

#Ouvrir bd

covidurl <- "https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/csse_covid_19_data/csse_covid_19_daily_reports/12-04-2022.csv"
covidData <- read.csv(covidurl,h=T)

str(covidData)

Dashboard <- covidData %>%
  select(Country_Region, Confirmed, Deaths) %>% 
  group_by(Country_Region) %>%
  summarise(Deaths = sum(Deaths),
            Confirmed = sum(Confirmed))

world <- map_data("world")

Dashboard <- left_join(world, Dashboard, by=c("region"= "Country_Region")) #Croisement entre bdd covid et carte du monde

#Creation de la carte finale

ggplot() +
  geom_map(data = Dashboard, map = world,
           aes(x=long,y=lat,map_id=region, fill=Deaths),
           color = "white")+ scale_fill_viridis_c(option = "C")




# Probleme: Quel code ISO pour les pays manquants?

worldmapVALUES<- setdiff(world$region, covidData$Country_Region)
covidVALUES<- setdiff(covidData$Country_Region, world$region)

covidVALUES <- c(covidVALUES, rep(NA, 74-23))
DIFFERENCE %>% tibble(worldmapVALUES, covidVALUES) %>% filter(covidVALUES)

guess_field(covidData$Country_Region, min_similarity = 82)


######################################CARTE DE FRANCE###############################################################

#Ouvrir bdd 

bdd_France <- read_excel("donnees-deces-hopital-2020-05-07.xlsx")  #pas réussi a l'importer directement sur le script 
                                                                   #donc je l'ai telecharger sur rstudio



#Création de la carte

france <- map_data("france")

mapdata <- left_join(france, bdd_France, by=c("region"= "Dept_Nom"))

mapplot<-ggplot() +
  geom_map(data = mapdata, map = mapdata, 
           aes(x=long,y=lat,map_id=region, fill= Nb_décès_par_millier),
           color = "white")+ scale_fill_viridis_c(option = "C")

#Trouver les noms qui match pas 

nonmatched1<-setdiff(bdd_France$Dept_Nom, france$region)
nonmatched2<-setdiff(france$region, bdd_France$Dept_Nom)


maxlength = max(length(nonmatched1), length(nonmatched2))
nonmatched2 = c(nonmatched2, rep(NA, maxlength - length(nonmatched2)))
different<-data.frame(nonmatched1, nonmatched2)

#Renomer les noms de departements

bdd_France <- bdd_France %>% mutate(Dept_Nom = recode(Dept_Nom, 
                                                      "Val-d'Oise" = "Val-Doise",
                                                      "Côte-d'Or" = "Cote-Dor", 
                                                      "Haute-Saône" = "Haute-Saone", 
                                                      "Rhône" = "Rhone",
                                                      "Saône-et-Loire" = "Saone-et-Loire", 
                                                      "Corse-du-Sud" = "Corse du Sud", 
                                                      "Ardèche" = "Ardeche", 
                                                      "Drôme" = "Drome", 
                                                      "Bouches-du-Rhône" = "Bouches-du-Rhone",
                                                      "Corrèze" = "Correze",
                                                      "Nièvre" ="Nievre" ,
                                                      "Hautes-Pyrénées" = "Hautes-Pyrenees" ,
                                                      "Hérault" = "Herault",
                                                      "Isère" = "Isere", 
                                                      "Pyrénées-Orientales" = "Pyrenees-Orientales",
                                                      "Puy-de-Dôme" = "Puy-de-Dome" ,
                                                      "Deux-Sèvres" = "Deux-Sevres", 
                                                      "Vendée" = "Vendee", 
                                                      "Côtes-d'Armor" = "Cotes-Darmor", 
                                                      "Finistère" = "Finistere" , 
                                                      "Pyrénées-Atlantiques" = "Pyrenees-Atlantiques", 
                                                      "Lozère" = "Lozere", 
                                                      "Ariège" = "Ariege"))

#La carte de France après avoir renomer 

mapdata <- left_join(france, bdd_France, by=c("region"= "Dept_Nom"))

p <- mapplot<-ggplot() +
  geom_map(data = mapdata, map = mapdata, 
           aes(x=long,y=lat,map_id=region, fill= Nb_décès_par_millier),
           color = "white")+ scale_fill_viridis_c(option = "C")
p

###########################################SERIE TEMPORELLE DE CERTAINS PAYS, DONT LA FRANCE################################################
raw_deaths <- read.csv(
    "https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/csse_covid_19_data/csse_covid_19_time_series/time_series_covid19_deaths_global.csv",
    check.names = FALSE
  )
deaths <- raw_deaths %>%
  rename(Country.Region = "Country/Region", Province.State = "Province/State") %>%
  pivot_longer(
    cols = -c("Country.Region", "Province.State", "Lat", "Long"),
    names_to = "Date",
    values_to = "Deaths" 
  ) %>%
  mutate(Date = mdy(Date)) %>%
  mutate(daily_deaths = Deaths - lag(Deaths, default = 0))


timeseries <- deaths %>%
  filter(
    Country.Region %in% c(
      "France",
      "Indonesia",
      "US",
      "Italy",
      "Brazil",
      "India",
      "Russia",
      "Mexico",
      "Peru",
      "United Kingdom"
    ),
    Date >= "2022-01-01"
  ) %>%
  ggplot(aes(x = Date, y = daily_deaths, color = Country.Region)) +
  scale_y_continuous(expand = c(0, 0), limits = c(0, 4500)) +
  theme_minimal() +     #limite pour ne pas voir de valeur négative
  labs(title = "Covid-19 Daily Deaths", x = "Date", y = "Daily Deaths") +
  theme(plot.title = element_text(hjust = 0.5)) + geom_smooth()
timeseries

